Fill all requirements before sending issues. Or all issues will be closed without reading. 

- [ ] Searched and checked other issues about my problem
- [ ] If have errors.log file and i did upload it

Check One :
- [ ] Bug
- [ ] Feature
- [ ] Need Help

## What OS ?
MAC / Windows / Linux(detail) / Android
## Python Version ?
2x / 3x
## Is it VPS ?
Yes / No
### VPS: Is the vps far far away ? Another Country ?
Yes / No
- [ ] VPS: Tried the same code via my local pc

## What is your python knowledge vote 0/10
