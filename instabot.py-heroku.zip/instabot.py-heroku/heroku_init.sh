#!/usr/bin/env bash

heroku create
heroku buildpacks:add heroku/python
heroku plugins:install heroku-config
heroku config:push
